import { KEPLISTA } from "./adatok";
import "./App.css";
import Galeria from "./components/Galeria";
import Nagykep from "./components/Nagykep";

export default function App() {
  return (
    <>
      <header>
        <h1>Képgaléria</h1>
      </header>
      <main>
        <Nagykep kep={KEPLISTA[0]} />
        <Galeria kep={KEPLISTA[0]} />
      </main>
      <footer>Huszár Fruzsina Anna</footer>
    </>
  );
}
